# 任务说明：blhscztj 晚间只测活 + 代码整理 + 仓库清理

- 仓库：`13510954098/blhscztj`，目标分支 `main`
- 基线提交：`08c95fd`（feat(schedule): 精确定时器 + 出口国家判定改用 Cloudflare loc (#5)）
- 工作分两部分：第二、三节是代码改动（走 PR），第四节是仓库清理（用 gh 直接操作）。
- 本包内容：
  - `TASK.md`：本说明
  - `changes.patch`：相对基线的完整补丁（含文件重命名），**首选**
  - `files/`：改动后的完整文件，目录结构与仓库一致（补丁打不上时用）

本补丁不涉及 `sub/`、`history/`、`.schedule/`。机器人在这几个目录的新提交不会造成冲突。

---

## 一、背景（只读，帮助理解）

1. 上一版（#5）已上线：
   - `timer.yml` 自维持定时任务链，在 **11:00 / 21:00（北京时间）** 两个时段调起 `update.yml`。
   - 出口国家改为以 Cloudflare `/cdn-cgi/trace` 返回的 `loc` 为准。
2. 站点每天只更新一次，大约在 08:30–10:40。所以 21:00 重新抓取没有意义，只需要重新测活，把白天失效的节点剔掉。
3. 仓库里有三份内容完全相同的 `geoip.metadb`，每份 8MB：
   - 位置：`sub/`、`sub/merged/`、`sub/alive/`。
   - 后两份是 `mihomo -t -d <目录>` 自动下载的副产品，没有任何代码读取。
4. `fetch_jcnode.py` 放在仓库根目录，其余脚本都在 `scripts/`。`update.yml` 为此专门写了两个"定位脚本"步骤。
5. 有少量未使用的导入和变量（pyflakes 报出）。

---

## 二、工作内容（补丁已实现，逐项核对即可）

### A. 晚间只测活
- `scripts/schedule_gate.py`：
  - 新增 `run_mode(slot, state, event, trigger)`，返回 `'alive'` 或 `'full'`。
  - 返回 `'alive'` 需同时满足：
    - 本次是定时触发：`schedule` 事件，或 `workflow_dispatch` 且 `trigger=timer`；
    - 时段是 `YYYY-MM-DD/21:00`；
    - 发布状态 `.schedule/success.json` 里的 `slot` 等于**同一天**的 `YYYY-MM-DD/11:00`。
  - 其余情况一律 `'full'`，包括手动触发、当天 11:00 没成功、早间时段。
  - 主流程向 `GITHUB_OUTPUT` 额外输出 `mode=...`，并写入 Step Summary。
- `.github/workflows/update.yml`：
  - `gate` job 新增输出 `mode`。
  - 下列步骤加 `if: needs.gate.outputs.mode != 'alive'`：
    - 抓取到临时目录（不碰旧订阅）
    - 自动修复每日 Clash 常见格式并校正元数据
    - 保存当天订阅（覆盖 daily，保留综合版）
    - 合并到综合订阅（当日结构模板，全库按 MB/s 排序）
    - 修复综合 Clash 中 FlClash 不接受的路径控制字符
  - 提交步骤：`mode=alive` 时，提交标题为 `chore(alive): 晚间复测存活节点 <时间>`，否则保持原标题。
- `tests/test_schedule_gate.py`：新增 `test_evening_mode_is_alive_only_after_morning_published`。

### B. `geoip.metadb` 只保留 `sub/` 一份
- `update.yml` 中所有执行 `.tools/mihomo -t -d <目录>` 的步骤：
  - 在 `set -euo pipefail` 后定义：
    ```bash
    reuse_geoip() { [ "$1" = sub ] || [ ! -s sub/geoip.metadb ] || cp -f sub/geoip.metadb "$1/geoip.metadb"; }
    ```
  - 每次 `mihomo -t` 之前先调用 `reuse_geoip <目录>`，避免重复下载。
  - 涉及 3 个步骤：mihomo 预校验、校验新生成的存活订阅、mihomo 最终校验。
  - `.tools/smoke` 那个内核自检**不改**。
- 提交步骤里，在 `git add sub history` 之前加上：
  ```bash
  rm -f sub/merged/geoip.metadb sub/alive/geoip.metadb
  git rm -q --cached --ignore-unmatch sub/merged/geoip.metadb sub/alive/geoip.metadb
  ```
  下一次更新运行时，会自动把这两个文件从仓库移除，**不需要手动删**。
- `.gitignore` 追加 `sub/merged/geoip.metadb`、`sub/alive/geoip.metadb`。
- **必须保留** `sub/geoip.metadb`。测活步骤 `test -s sub/geoip.metadb` 和 `normalize_country_groups.py` 都要用到它。

### C. 代码整理
- `git mv fetch_jcnode.py scripts/fetch_jcnode.py`。文件内容不变，它的 docstring 本来就写的是 `scripts/fetch_jcnode.py`。
- `update.yml` 删除"定位抓取脚本"和"定位合并脚本"两个步骤，改为固定路径：
  - `SCRIPT="scripts/fetch_jcnode.py"`
  - `MERGER="scripts/merge_subscriptions.py"`
- `tests/test_pipeline.py` 删除 `sys.path.insert(0, str(ROOT))`，根目录已经没有模块；保留 `ROOT / "scripts"`。
- 删除未使用代码：
  - `scripts/mihomo_alive_check.py`：
    - 删掉导入 `SPECIAL_PROXY_REFS`、`_parse_ss_base64`、`country_code_from_flag as _country_code_from_flag`；
    - 删掉 `clash_connection_key()` 里未使用的 `reality = ...`。**同文件另一个函数里也有 `reality`，那个在用，不要删。**
    - 删掉未使用的 `bad_names = ...`。
  - `scripts/normalize_country_groups.py`：删掉导入 `country_code_from_flag`。
  - **保留** `mihomo_alive_check.py` 里的 `country_for_ip as _country_for_ip`。pyflakes 会报它未使用，但测试里通过 `mihomo_check._country_for_ip` 在用。

---

## 三、操作步骤

> 建议在当天 11:00 那次 "Update JCNode subscription" **运行结束后**再合并，避免和机器人提交交错。补丁本身不碰 `sub/`，即使交错也不会冲突。

1. 同步最新 main，新建分支：
   ```bash
   git checkout main && git pull
   git checkout -b chore/evening-alive-and-cleanup
   ```
2. 应用补丁（首选）：
   ```bash
   git apply --index changes.patch
   ```
   如果打不上，改用 `files/` 里的完整文件：
   ```bash
   cp -r files/. .            # 覆盖 8 个文件
   git rm fetch_jcnode.py     # 根目录旧文件必须删除
   git add -A
   ```
3. 本地验证（Python 3.12）：
   ```bash
   python -m pip install PyYAML maxminddb
   python -m unittest discover -s tests -v      # 期望：Ran 83 tests ... OK
   python -c "import yaml;[yaml.safe_load(open(f)) for f in ['.github/workflows/update.yml','.github/workflows/timer.yml']]"
   test ! -e fetch_jcnode.py && test -f scripts/fetch_jcnode.py
   grep -c "locate-" .github/workflows/update.yml   # 期望 0
   grep -n "reuse_geoip" .github/workflows/update.yml # 期望 7 行：3 处定义 + 4 处调用
   ```
4. 提交并开 PR，合并到 main：
   ```
   chore: 晚间只测活 + geoip.metadb 去重 + fetch_jcnode.py 移入 scripts/

   - schedule_gate: run_mode()，当天 11:00 已发布时 21:00 只复测（跳过抓取/合并）
   - update.yml: mode 输出；抓取/合并相关 5 步按 mode 跳过；alive 提交标题
   - geoip.metadb 只保留 sub/ 一份：mihomo -t 前复用、提交前移除副本并 gitignore
   - fetch_jcnode.py 移入 scripts/，删除两个定位步骤
   - 清理未使用的导入/变量（保留测试用的 _country_for_ip）
   ```
5. 完成第四节「仓库清理」（**必须做**，可以在合并 PR 之后进行）。

---

## 四、仓库清理（必须完成）

以下是我检查仓库时发现的遗留，全部删除不会影响订阅更新。需要 `gh` CLI，并对仓库有 admin/write 权限。

```bash
export GH_REPO=13510954098/blhscztj
```

| # | 遗留项 | 现状 | 处理 |
|---|---|---|---|
| 1 | 分支 `arena/01a10be5-blhscztj` | PR #1、#3、#4 都已关闭，分支还在 | 删除 |
| 2 | 工作流 "TEMP fetch gofile"（`.github/workflows/tmp-fetch-gofile.yml`，ID `380956165`） | 文件只存在于已删除的分支上，但 Actions 里仍显示为 active，留有 8 条运行记录 | 先停用，再删除全部运行记录（删完后它会从工作流列表消失） |
| 3 | 工作流 "Tests" 的 2 条失败记录 | 该工作流文件早已不存在 | 删除记录 |
| 4 | "Update JCNode subscription" 的历史失败/取消记录 | 7 条 failure、1 条 cancelled，都是 10/6 之前调试期留下的 | 删除记录。**不要删正在运行或排队的记录** |
| 5 | 仓库设置 "Automatically delete head branches" | 未开启，所以每个 PR 合并后都留下 `arena/*` 分支 | 开启 |
| 6 | Actions 产物（artifacts） | 14 个，约 213MB，7 天后会自动过期 | 只删已结束运行的旧产物，保留最近 2 个 |

```bash
# 1. 删除遗留分支（以及其他所有 arena/* 分支）
for b in $(gh api "repos/$GH_REPO/branches" --paginate --jq '.[].name | select(startswith("arena/"))'); do
  gh api -X DELETE "repos/$GH_REPO/git/refs/heads/$b" && echo "deleted branch $b"
done

# 2. 停用 TEMP 工作流，并删除它的全部运行记录
gh api -X PUT "repos/$GH_REPO/actions/workflows/380956165/disable" || true
gh api "repos/$GH_REPO/actions/workflows/380956165/runs" --paginate --jq '.workflow_runs[].id' \
  | xargs -r -I{} gh api -X DELETE "repos/$GH_REPO/actions/runs/{}"

# 3 + 4. 删除 "Tests" 的全部记录，以及 Update 工作流已结束的 failure/cancelled 记录
gh api "repos/$GH_REPO/actions/runs" --paginate \
  --jq '.workflow_runs[]
        | select(.status == "completed")
        | select(.name == "Tests"
                 or (.name == "Update JCNode subscription" and (.conclusion == "failure" or .conclusion == "cancelled")))
        | .id' \
  | xargs -r -I{} gh api -X DELETE "repos/$GH_REPO/actions/runs/{}"

# 5. 开启"合并后自动删除分支"
gh api -X PATCH "repos/$GH_REPO" -F delete_branch_on_merge=true --jq .delete_branch_on_merge   # 期望 true

# 6. 删除旧产物，保留最新 2 个
gh api "repos/$GH_REPO/actions/artifacts" --paginate --jq '.artifacts | sort_by(.created_at) | reverse | .[2:][] | .id' \
  | xargs -r -I{} gh api -X DELETE "repos/$GH_REPO/actions/artifacts/{}"
```

**清理后的检查：**
```bash
gh api "repos/$GH_REPO/branches" --jq '[.[].name]'                      # 期望 ["main"]
gh api "repos/$GH_REPO/actions/workflows" --jq '[.workflows[] | "\(.name):\(.state)"]'
#   期望只剩 "Precise timer:active"、"Update JCNode subscription:active"
#   （如果 TEMP 仍在列表里，状态应为 disabled_manually）
gh api "repos/$GH_REPO/actions/runs?per_page=100" \
  --jq '[.workflow_runs[] | select(.name=="Tests" or .name=="TEMP fetch gofile")] | length'   # 期望 0
gh api "repos/$GH_REPO" --jq .delete_branch_on_merge                     # 期望 true
```

**清理时不要动：**
- `main` 分支本身，以及 "Precise timer" 正在运行或排队的记录。删掉正在运行的那条会打断定时任务链；万一误删，在 Actions 页面手动运行一次 "Precise timer" 即可恢复。
- 成功的历史运行记录。
- 已关闭的 PR（保留作为历史）。
- **不要**改写 git 历史（filter-repo、force push 等）来清理大文件。

---

## 五、合并后的验收

| 时间点 | 应该看到 |
|---|---|
| 合并后 1 分钟内 | `schedule_gate.py` 被修改，会触发一次 "Precise timer"（push 事件）。同一时间最多一个在运行、一个在排队，属于正常 |
| 下一个 11:00 | 定时器调起 "Update JCNode subscription"，事件为 `workflow_dispatch`。gate 的 Summary 显示 `mode: full`；提交标题为 `chore(sub): 去重合并 JCNode 订阅 …` |
| 上述运行的提交 | `sub/merged/geoip.metadb`、`sub/alive/geoip.metadb` 被删除；`sub/geoip.metadb` 仍在 |
| 同日 21:00 | gate 的 Summary 显示 `mode: alive`。日志里抓取、修复、保存、合并、路径修复 5 步为 skipped；提交标题为 `chore(alive): 晚间复测存活节点 …` |
| 21:00 的反例 | 当天 11:00 没成功时，21:00 应为 `mode: full`，照常抓取 |

---

## 六、不要做的事
- 不要改动 `sub/`、`history/`、`.schedule/` 里的数据文件。
- 不要删除 `sub/geoip.metadb`。
- 不要裁剪综合订阅（`sub/merged`）里的节点。仓库主人已明确选择保留全部节点。
- 不要修改 `timer.yml` 的调度逻辑，以及 `schedule_gate.py` 里 `plan()` 的重试参数（每时段 4 次、间隔 30 分钟、最长睡眠 5.5 小时）。
- 不要删除 `_country_for_ip` 导入。

## 七、回滚
直接 revert 本次合并提交即可。`sub/` 里被移除的两份 `geoip.metadb` 不需要恢复：下次 `mihomo -t` 会重新下载，或者回滚后的工作流会照旧生成。
